const InboardListPage = () => {
  return <></>
}
export default InboardListPage
