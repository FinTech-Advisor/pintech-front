import React from 'react'

const List = () => {
  return <h1>default</h1>
}

export default React.memo(List)
