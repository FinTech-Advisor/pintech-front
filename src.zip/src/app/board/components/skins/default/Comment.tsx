import React from 'react'

const Comment = () => {
  return <h1>default</h1>
}

export default React.memo(Comment)
