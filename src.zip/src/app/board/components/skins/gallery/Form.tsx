import React from 'react'

const Form = () => {
  return <h1>gallery</h1>
}

export default React.memo(Form)
