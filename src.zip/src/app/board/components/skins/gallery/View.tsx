import React from 'react'

const View = () => {
  return <h1>Gallery</h1>
}

export default React.memo(View)
