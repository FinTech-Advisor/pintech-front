import React from 'react'

const List = () => {
  return <h1>Gallery</h1>
}

export default React.memo(List)
