import React from 'react'

const Comment = () => {
  return <h1>Gallery</h1>
}

export default React.memo(Comment)
