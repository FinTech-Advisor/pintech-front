const sizes = {
  tiny: '0.65rem',
  small: '0.85rem',
  normal: '1rem',
  medium: '1.25rem',
  big: '1.5rem',
  extra: '2rem',
}

export default sizes
