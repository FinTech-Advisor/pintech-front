const UserViewPage = () => {
    return <h1>유저 대출 단일 조회</h1>
  }
  
  export default UserViewPage
  