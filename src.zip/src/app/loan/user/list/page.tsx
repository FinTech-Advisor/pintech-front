const UserListPage = () => {
    return <h1>유저 대출 목록 조회</h1>
  }
  
  export default UserListPage
  