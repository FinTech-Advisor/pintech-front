const LoanViewPage = () => {
    return <h1>대출 단일 조회</h1>
  }
  
  export default LoanViewPage
  