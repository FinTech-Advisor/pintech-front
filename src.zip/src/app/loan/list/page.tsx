const LoanListPage = () => {
    return <h1>대출 목록 조회</h1>
  }
  
  export default LoanListPage
  