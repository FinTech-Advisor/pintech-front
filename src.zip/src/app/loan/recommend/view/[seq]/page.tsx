const RecommendViewPage = () => {
  return <h1>추천 대출 로그 단일 조회</h1>
}

export default RecommendViewPage
