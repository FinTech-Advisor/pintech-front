const RecommendListPage = () => {
    return <h1>추천 대출 로그 목록 조회</h1>
  }
  
  export default RecommendListPage
  