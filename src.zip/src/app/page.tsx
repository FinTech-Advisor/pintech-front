const MainPage = () => {
  return <h1>mainpage</h1>
}
export default MainPage
