const AccountViewPage = () => {
    return <h1>계좌 단일 조회</h1>
  }
  
  export default AccountViewPage
  