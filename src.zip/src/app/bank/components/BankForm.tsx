import React from "react";

const BankForm = () => {
    return <h1>test</h1>
}

export default React.memo(BankForm)